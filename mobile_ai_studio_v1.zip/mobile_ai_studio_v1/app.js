const KEY="mobile-ai-studio-v1";
const state=JSON.parse(localStorage.getItem(KEY)||'{"projects":[],"agents":[],"notes":[]}');
const save=()=>localStorage.setItem(KEY,JSON.stringify(state));
const $=id=>document.getElementById(id);
function go(id){document.querySelectorAll(".view").forEach(v=>v.classList.toggle("active",v.id===id));document.querySelectorAll("nav button").forEach(b=>b.classList.toggle("active",b.dataset.go===id));window.scrollTo(0,0);render()}
document.querySelectorAll("[data-go]").forEach(b=>b.addEventListener("click",()=>go(b.dataset.go)));
function render(){
 $("projectList").innerHTML=state.projects.length?state.projects.map((p,i)=>`<div class="panel item"><strong>${esc(p.name)}</strong><small>${esc(p.desc)}</small><div style="text-align:right;margin-top:8px"><button data-del-project="${i}">Delete</button></div></div>`).join(""):'<div class="empty">No projects yet. Add your first project above.</div>';
 $("agentList").innerHTML=state.agents.length?state.agents.map((a,i)=>`<div class="panel item"><strong>${esc(a.name)}</strong><small>${esc(a.role)}</small><p class="small">${esc(a.rules)}</p><span class="status">DRAFT · NOT DEPLOYED</span><div style="text-align:right;margin-top:8px"><button data-del-agent="${i}">Delete</button></div></div>`).join(""):'<div class="empty">No agent designs yet.</div>';
 $("chatNotes").innerHTML=state.notes.length?state.notes.map(n=>`<div class="item">${esc(n)}</div>`).join(""):'No saved notes yet.';
 document.querySelectorAll("[data-del-project]").forEach(b=>b.onclick=()=>{state.projects.splice(+b.dataset.delProject,1);save();render()});
 document.querySelectorAll("[data-del-agent]").forEach(b=>b.onclick=()=>{state.agents.splice(+b.dataset.delAgent,1);save();render()});
}
function esc(s){return String(s||"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
$("addProject").onclick=()=>{let name=$("projectName").value.trim();if(!name)return alert("Add a project name.");state.projects.unshift({name,desc:$("projectDesc").value.trim()});$("projectName").value="";$("projectDesc").value="";save();render()};
$("addAgent").onclick=()=>{let name=$("agentName").value.trim();if(!name)return alert("Add an agent name.");state.agents.unshift({name,role:$("agentRole").value.trim(),rules:$("agentRules").value.trim()});$("agentName").value="";$("agentRole").value="";$("agentRules").value="";save();render()};
$("saveNote").onclick=()=>{let v=$("prompt").value.trim();if(!v)return alert("Write a note first.");state.notes.unshift(v);save();$("prompt").value="";render()};
$("copyPrompt").onclick=async()=>{let v=$("prompt").value;if(!v.trim())return alert("Write a prompt first.");try{await navigator.clipboard.writeText(v);alert("Prompt copied. Open ChatGPT and paste it.")}catch(e){alert("Clipboard unavailable. Select and copy the text manually.")}};
const openGPT=()=>window.open("https://chatgpt.com/","_blank","noopener");$("openGPT").onclick=openGPT;$("openGPT2").onclick=openGPT;
$("exportData").onclick=()=>{let blob=new Blob([JSON.stringify(state,null,2)],{type:"application/json"});let a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="mobile-ai-studio-backup.json";a.click();URL.revokeObjectURL(a.href)};
$("clearData").onclick=()=>{if(confirm("Delete all Mobile AI Studio data stored in this browser? This cannot be undone.")){localStorage.removeItem(KEY);location.reload()}};
render();
if("serviceWorker" in navigator && location.protocol.startsWith("http"))navigator.serviceWorker.register("./sw.js").catch(()=>{});
